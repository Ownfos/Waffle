#ifndef RECTANGLE_H
#define RECTANGLE_H

namespace waffle
{
    struct Rectangle
    {
        long width = 0;
        long height = 0;
    };
}

#endif